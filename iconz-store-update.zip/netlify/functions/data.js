// netlify/functions/data.js
//
// This is the site's real backend. It stores one JSON "blob" (the whole
// ICONZ store data — sections, products, theme, logo, etc.) using Netlify
// Blobs, which is included free on every Netlify site (no credit card,
// no paid plan required).
//
//   GET  -> anyone can read the current live data (used by every visitor)
//   POST -> only requests with the correct admin passcode can overwrite it
//
// Set an ADMIN_PASSCODE environment variable in your Netlify site settings
// (Site configuration -> Environment variables) for real security. If you
// don't set one, it falls back to the same passcode used in the site
// itself ("2580") so everything still works out of the box.

const { getStore } = require('@netlify/blobs');

const STORE_NAME = 'iconz-store';
const KEY = 'siteData';
const FALLBACK_PASSCODE = '2580';

function getStoreSafe() {
  return getStore({ name: STORE_NAME, consistency: 'strong' });
}

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store',
  };

  try {
    if (event.httpMethod === 'GET') {
      const store = getStoreSafe();
      const raw = await store.get(KEY);
      const data = raw ? JSON.parse(raw) : null;
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ data }),
      };
    }

    if (event.httpMethod === 'POST') {
      const auth = event.headers.authorization || event.headers.Authorization || '';
      const token = auth.replace(/^Bearer\s+/i, '').trim();
      const expected = process.env.ADMIN_PASSCODE || FALLBACK_PASSCODE;

      if (!token || token !== expected) {
        return {
          statusCode: 401,
          headers,
          body: JSON.stringify({ error: 'Unauthorized' }),
        };
      }

      let payload;
      try {
        payload = JSON.parse(event.body || '{}');
      } catch (e) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Invalid JSON body' }),
        };
      }

      if (!payload || typeof payload !== 'object') {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Body must be a JSON object' }),
        };
      }

      const store = getStoreSafe();
      await store.set(KEY, JSON.stringify(payload));

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ ok: true }),
      };
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' }),
    };
  } catch (err) {
    console.error('data function error:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', message: String(err && err.message || err) }),
    };
  }
};
