# ICONZ Store — Setup Guide

## What changed

Your site used to save everything only in the browser's `localStorage`, so admin
edits only existed on your own device. That's fixed now:

- **Real shared backend** — a Netlify Function (`netlify/functions/data.js`)
  backed by Netlify Blobs storage now holds the live store data. Netlify Blobs
  is free on every Netlify site, no credit card, no paid plan.
- **"☁️ Save Changes" bar** — appears at the bottom of the screen whenever
  you're in admin mode. It tells you "You have unsaved changes" or "Everything
  is saved and live." Nothing is visible to other visitors until you tap it.
- **Refresh-safe drafts** — while you're editing, your in-progress changes are
  cached on your device too, so refreshing your own browser never wipes your
  work — even before you hit Save.
- **Full branding & theme controls** in the admin dashboard: business name,
  logo upload, background photo, and color pickers for background/cards/text/
  gold accent/teal accent.
- **Product photos**: up to 8 per product now (was 3), so you can show items
  from multiple angles like larger stores do.
- **Product descriptions**: new optional English/Arabic description fields,
  shown on the product page under the price.
- **Image compression**: every photo you upload (logo, background, banners,
  size chart, product photos) is automatically resized/compressed in the
  browser before saving, so the site stays fast and reliable.
- Nothing was removed — all your existing sections, leagues, groups, products,
  cart logic, checkout flow, WhatsApp button, and Arabic/English toggle work
  exactly as before.

## How to deploy this update

You're moving from a single HTML file to a small project folder — that's
required to add the real backend. Steps:

1. **If your site is connected to a GitHub repo:** copy these files into that
   repo (replacing your old HTML file with `index.html`), commit, and push.
   Netlify will redeploy automatically.

2. **If you deploy by drag-and-drop on Netlify:** go to your Netlify site's
   **Deploys** tab, and drag the whole folder (containing `index.html`,
   `netlify.toml`, `package.json`, and the `netlify` folder) onto the deploy
   area. Keep the folder structure exactly as given — don't rename or move
   `netlify/functions/data.js`.

3. **(Recommended, 1 minute) Set a private admin passcode on the server too:**
   In Netlify: **Site configuration → Environment variables → Add a variable**
   - Key: `ADMIN_PASSCODE`
   - Value: the same passcode you use to enter admin mode on the site
     (currently `2580` in the code — change it in both places if you want a
     new one)
   
   This isn't required for things to work, but without it, anyone who
   inspects the site's code could technically find the fallback passcode and
   push changes to the live store. Setting the environment variable keeps
   your real passcode private.

4. **Redeploy** (pushing to GitHub or re-dragging the folder triggers this
   automatically). Netlify will install `@netlify/blobs` automatically — no
   extra setup needed.

That's it — after this deploy, whenever you tap **☁️ Save Changes** in admin
mode, every visitor to your site will see the update, even after they refresh
or come back later.

## A couple of things worth knowing

- **Storage limit**: Netlify Blobs' free tier is generous, but if you upload
  *hundreds* of full-resolution photos the site's data could get large. The
  automatic compression keeps this in check for normal use (dozens of
  products with several photos each is no problem).
- **One shared "live" version**: admin mode is still just your personal
  passcode gate — there's one live version of the store, not separate
  accounts. If you ever want multiple staff logins with different
  permissions, that's a bigger step we can plan separately.
